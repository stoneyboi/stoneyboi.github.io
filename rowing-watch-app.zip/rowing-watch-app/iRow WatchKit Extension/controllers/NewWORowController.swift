//
//  NewWORowController.swift
//  iRow WatchKit Extension
//
//  Created by Isabel Albaitis and Jacob Stone on 11/2/21.
//

import UIKit
import WatchKit

class NewWORowController: NSObject {
    
    @IBOutlet weak var typeLabel: WKInterfaceLabel!
    
}
